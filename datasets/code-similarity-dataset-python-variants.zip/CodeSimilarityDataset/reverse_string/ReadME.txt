Title: Code Similarity Dataset - Reverse String
Author: Hem Ajit Patel
Description: This dataset contains 20 different Python functions that reverse a string.
             Useful for studying code similarity, plagiarism detection, and code search.

Files:
- snippets/*.py – individual code snippets solving the same task
- metadata.csv – info about each snippet (method used)