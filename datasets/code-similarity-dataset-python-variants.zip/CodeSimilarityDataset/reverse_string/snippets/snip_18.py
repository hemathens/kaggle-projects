def reverse_string(s):
    return ''.join(s[i] for i in reversed(range(len(s))))