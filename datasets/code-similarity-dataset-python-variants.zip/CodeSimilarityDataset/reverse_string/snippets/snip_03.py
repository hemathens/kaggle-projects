def reverse_string(s):
    return ''.join(reversed(s))