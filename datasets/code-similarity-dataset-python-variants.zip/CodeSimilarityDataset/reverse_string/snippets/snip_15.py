def reverse_string(s):
    output = ''
    for c in s:
        output = c + output
    return output