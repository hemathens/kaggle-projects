def reverse_string(s):
    s = list(s)
    s.reverse()
    return ''.join(s)