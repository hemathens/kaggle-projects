def reverse_string(s):
    return ''.join(c for c in ''.join(reversed(s)))