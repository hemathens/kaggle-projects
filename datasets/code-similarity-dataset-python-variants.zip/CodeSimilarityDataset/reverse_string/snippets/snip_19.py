def reverse_string(s):
    return ''.join([c for c in reversed(list(s))])