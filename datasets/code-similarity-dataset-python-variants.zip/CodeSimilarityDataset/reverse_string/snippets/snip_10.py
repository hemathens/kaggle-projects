def reverse_string(s):
    return ''.join(char for char in reversed(s))