def is_palindrome(s):
    return s == ''.join(reversed(s))