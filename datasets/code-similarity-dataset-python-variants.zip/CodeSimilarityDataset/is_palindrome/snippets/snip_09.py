def is_palindrome(s):
    return list(s) == list(reversed(s))