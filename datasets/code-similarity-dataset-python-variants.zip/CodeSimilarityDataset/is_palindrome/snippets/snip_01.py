def is_palindrome(s):
    return s == s[::-1]