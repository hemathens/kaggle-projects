def is_palindrome(s):
    return list(s) == list(s[::-1])