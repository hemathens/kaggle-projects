Title: Code Similarity Dataset - Find Max in List
Author: Hem Ajit Patel
Description: This dataset contains 20 different Python functions that find the maximum value in a list.
             Useful for studying code similarity, plagiarism detection, and code search.

Files:
- snippets/*.py – individual code snippets solving the same task
- metadata.csv – info about each snippet (method used)