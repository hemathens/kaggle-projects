def find_max(lst):
    return eval("max(" + str(lst) + ")")