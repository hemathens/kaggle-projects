def find_max(lst):
    return sorted(lst)[-1]