def find_max(lst):
    return max(lst)