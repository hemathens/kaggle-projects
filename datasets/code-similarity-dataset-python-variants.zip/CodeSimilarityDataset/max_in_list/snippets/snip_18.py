import numpy as np

def find_max(lst):
    return np.max(lst)